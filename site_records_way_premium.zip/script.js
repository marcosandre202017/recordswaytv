const items = document.querySelectorAll('.section, .why, .testimonials, .plan-card, .content-card, .poster');
items.forEach(item => item.classList.add('reveal'));

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add('active');
  });
}, { threshold: 0.12 });

items.forEach(item => observer.observe(item));
